
export const CANVAS_WIDTH = 600;
export const CANVAS_HEIGHT = 600;

export const INITIAL_STICKERS = [
  'https://em-content.zobj.net/source/apple/354/face-with-tears-of-joy_1f602.png',
  'https://em-content.zobj.net/source/apple/354/loudly-crying-face_1f62d.png',
  'https://em-content.zobj.net/source/apple/354/smiling-face-with-horns_1f608.png',
  'https://em-content.zobj.net/source/apple/354/fire_1f525.png',
  'https://em-content.zobj.net/source/apple/354/thinking-face_1f914.png',
  'https://em-content.zobj.net/source/apple/354/skull_1f480.png',
  'https://em-content.zobj.net/source/apple/354/clown-face_1f921.png',
  'https://em-content.zobj.net/source/apple/354/face-with-monocle_1f9d0.png',
  'https://em-content.zobj.net/source/apple/354/ok-hand_1f44c.png',
  'https://em-content.zobj.net/source/apple/354/100_1f4af.png',
  'https://em-content.zobj.net/source/apple/354/exploding-head_1f92f.png',
  'https://em-content.zobj.net/source/apple/354/alien_1f47d.png',
];
